﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;

namespace WPF_Course
{
    class GameDisplay
    {
        GameBoard theboard = new GameBoard();
        public void Gameover()
        {
            theboard.Return_Winner().ToString();
            MessageBox.Show(theboard.Return_Winner().ToString() + " win. Game Over!");
            Application.Current.MainWindow.Close();
        }
        public void ChooseBlank()
        {
            MessageBox.Show("You have chosen the place that have no piece. Please choose again");
        }
        public void ChooseWrongSide()
        {
            MessageBox.Show("Sorry, you choose the wrong side piece.Please choose again");
        }
        public void CantGo()
        {
            MessageBox.Show("Sorry, you can not go there. Please choose again");
        }
        public void CantsendGtoD()
        {
            MessageBox.Show("Sorry, you can not let your General die. Please choose again");
        }
    }
}

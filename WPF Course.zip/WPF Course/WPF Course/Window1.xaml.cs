﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WPF_Course
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        GameBoard theboard = new GameBoard();
        Piece[,] pieces = new Piece[10, 9];
        ArrayList list = new ArrayList();
        Button buttonSelected = new Button();
        GameDisplay display = new GameDisplay();
        public object ArrayList { get; private set; }
        public void InsertPicture(int col, int row,Button button)
        {
            ImageBrush bg = new ImageBrush();
            Piece[,] pieces = new Piece[10, 9];
            pieces = theboard.getPiece();
            button.Style = FindResource("MyButton") as Style;
            if (pieces[row, col].side == Player_side.red)
            {
                switch (pieces[row, col].type)
                {
                    case Piece_type.Advisor: bg.ImageSource = 
                            new BitmapImage(new Uri("Picture/ChineseChessGame/chess8.png", UriKind.RelativeOrAbsolute));
                        button.Background = bg;
                        break;
                    case Piece_type.General:
                        bg.ImageSource =
                            new BitmapImage(new Uri("Picture/ChineseChessGame/chess7.png", UriKind.RelativeOrAbsolute));
                        button.Background = bg;
                        break;
                    case Piece_type.Elephant:
                        bg.ImageSource =
                            new BitmapImage(new Uri("Picture/ChineseChessGame/chess9.png", UriKind.RelativeOrAbsolute));
                        button.Background = bg;
                        break;
                    case Piece_type.Horse:
                        bg.ImageSource =
                            new BitmapImage(new Uri("Picture/ChineseChessGame/chess10.png", UriKind.RelativeOrAbsolute));
                        button.Background = bg;
                        break;
                    case Piece_type.Rook:
                        bg.ImageSource =
                            new BitmapImage(new Uri("Picture/ChineseChessGame/chess11.png", UriKind.RelativeOrAbsolute));
                        button.Background = bg;
                        break;
                    case Piece_type.Soldier:
                        bg.ImageSource =
                            new BitmapImage(new Uri("Picture/ChineseChessGame/chess13.png", UriKind.RelativeOrAbsolute));
                        button.Background = bg;
                        break;
                    case Piece_type.Cannon:
                        bg.ImageSource =
                            new BitmapImage(new Uri("Picture/ChineseChessGame/chess12.png", UriKind.RelativeOrAbsolute));
                        button.Background = bg;
                        break;
                    default: break;
                }
            }
            if (pieces[row, col].side == Player_side.black)
            {
                switch (pieces[row, col].type)
                {
                    case Piece_type.Advisor:
                        bg.ImageSource =
                            new BitmapImage(new Uri("Picture/ChineseChessGame/chess1.png", UriKind.RelativeOrAbsolute));
                        button.Background = bg;
                        break;
                    case Piece_type.General:
                        bg.ImageSource =
                            new BitmapImage(new Uri("Picture/ChineseChessGame/chess0.png", UriKind.RelativeOrAbsolute));
                        button.Background = bg;
                        break;
                    case Piece_type.Elephant:
                        bg.ImageSource =
                            new BitmapImage(new Uri("Picture/ChineseChessGame/chess2.png", UriKind.RelativeOrAbsolute));
                        button.Background = bg;
                        break;
                    case Piece_type.Horse:
                        bg.ImageSource =
                            new BitmapImage(new Uri("Picture/ChineseChessGame/chess3.png", UriKind.RelativeOrAbsolute));
                        button.Background = bg;
                        break;
                    case Piece_type.Rook:
                        bg.ImageSource =
                            new BitmapImage(new Uri("Picture/ChineseChessGame/chess4.png", UriKind.RelativeOrAbsolute));
                        button.Background = bg;
                        break;
                    case Piece_type.Soldier:
                        bg.ImageSource =
                            new BitmapImage(new Uri("Picture/ChineseChessGame/chess6.png", UriKind.RelativeOrAbsolute));
                        button.Background = bg;
                        break;
                    case Piece_type.Cannon:
                        bg.ImageSource =
                            new BitmapImage(new Uri("Picture/ChineseChessGame/chess5.png", UriKind.RelativeOrAbsolute));
                        button.Background = bg;
                        break;
                    default: break;
                }
            }
        }

        public void CreateGrid()
        {
            this.Content = GameBoardGird;
            ImageBrush bg = new ImageBrush();
            bg.ImageSource = new BitmapImage(new Uri("Picture/ChineseChessGame/bj2.png", UriKind.RelativeOrAbsolute));
            Background = bg;
            Piece[,] pieces = new Piece[10, 9];
            pieces = theboard.getPiece();
           
            for (int row = 0; row < 10; row++)
            {
                for (int col = 0; col < 9; col++)
                {
                    Button button = new Button();
                    if (pieces[row, col].type != Piece_type.blank)
                    {
                        InsertPicture(col, row, button);
                    }
                    else
                       button.Opacity=0;
                    string name = "Button";
                    name += col.ToString() + row.ToString();
                    RegisterName(name, button);
                    button.Name = "Button" + col.ToString() + row.ToString();
                    button.Click += new RoutedEventHandler(Button_Click);
                    Grid.SetRow(button, row);
                    Grid.SetColumn(button, col);
                    GameBoardGird.Children.Add(button);

                }
            }
            this.state.Text = "Current state:" + theboard.GetGameState().ToString();
            this.side.Text = "Current side:" + theboard.GetCurrentSide().ToString();
        }
        public void RedrawGrid()
        {
            ImageBrush bg = new ImageBrush();
            bg.ImageSource = new BitmapImage(new Uri("Picture/ChineseChessGame/chessBoard.png", UriKind.RelativeOrAbsolute));
            GameBoardGird.Background = bg;
        }
        public Window1()
        {
            InitializeComponent();
            CreateGrid();
            RedrawGrid();
        }
        public ArrayList HightLightButton()
        {
            ArrayList myList = new ArrayList();
            myList = theboard.ReturnPiece();
            foreach (Piece piece in myList)
            {
                string name = "Button";
                name += piece.Gethorizontal().ToString();
                name += piece.Getvertical().ToString();
                Button button = (Button)FindName(name);
                button.Opacity = 0.3;
                button.Foreground = System.Windows.Media.Brushes.Blue;
            }
            return myList;
        }
        public void RedrawButton(Button button)//将能去地方的按钮重新处理
        {
            string location;
            location= button.Name.ToString();
            ArrayList myList = new ArrayList();
            myList = list;
            int[] LocationArray = new int[2] { -1,-1 };//记录选择要去地方的坐标
            LocationArray[0] = location[6] - 48;
            LocationArray[1] = location[7] - 48;
            button.Opacity = 1;
            button.Style = FindResource("MyButton") as Style;
            if (button.Name != buttonSelected.Name)
            {
                button.Background = buttonSelected.Background;//移动按钮图片去到要去的位置
                buttonSelected.Background = new SolidColorBrush(Colors.LightGray);
                buttonSelected.Opacity = 0;
                button.Opacity = 1;
            }
                foreach (Piece piece in myList)
                {
                    string name = "Button";
                    name += piece.Gethorizontal().ToString();
                    name += piece.Getvertical().ToString();
                    Button Button_redraw = (Button)FindName(name);
                    if (LocationArray[0] == piece.Gethorizontal() && LocationArray[1] == piece.Getvertical()) { }//已经去了的地方
                    else if (piece.type == Piece_type.blank)//除去已经去了的地方，剩下的按钮要是是空棋子则透明度为0
                    {
                        Button_redraw.Opacity = 0;
                        Button_redraw.Background = System.Windows.Media.Brushes.LightGray;
                    }
                    else
                    {
                        Button_redraw.Opacity = 1;
                    }
                }
        }
        public void HandleButton(Button button)
        {
            
            pieces = theboard.getPiece();
            
            if (theboard.GetGameState() == GameState.Select)
            {
                if (theboard.boolSelected(button.Name.ToString(),display))
                {
                    buttonSelected = button;
                    //MessageBox.Show(button.Name.ToString());
                    list = HightLightButton();
                    theboard.SwitchGameState();
                    
                }
            }
            else
            {
                if (theboard.boolTogo(button.Name.ToString(),display))
                {
                    string selected = "Button";
                    selected += theboard.getSelectedX().ToString();
                    selected += theboard.getSelectedY().ToString();
                    RedrawButton(button);
                }
                theboard.SwitchGameState();
            }
        }
        public void Print()
        {
            state.Text = "Current state:" + theboard.GetGameState().ToString();
            side.Text = "Current side:" + theboard.GetCurrentSide().ToString();
            if (theboard.GetCurrentSide().ToString() == "red")
            {
                side.Foreground = new SolidColorBrush(Colors.Red);
            }
            else
                side.Foreground = new SolidColorBrush(Colors.Black);
        }
        public void GameOverJudge()
        {
            if (!theboard.getGeneralAlive())
            {
                display.Gameover();
            }
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Button button = (Button)sender;
            HandleButton(button);
            Print();
            GameOverJudge();
        }
    }
}
